document.querySelector("#btnEjer1Ver").addEventListener("click",ejer1);
document.querySelector("#btnEjer18Ver").addEventListener("click",ejer18);


function ejer1(){
    let valor = document.querySelector("#txtEjer1Numero").value;
    let valorNumerico = Number(valor);
    let parrafo = document.querySelector("#pEjer1Resultado");
    /*if(isNaN(valorNumerico) || valor== "" ){
        parrafo.innerHTML = "Por favor ingrese un numero";
    }
    else if(valorNumerico >= 0){
        parrafo.innerHTML = "El numero es positivo";
    } else{
        parrafo.innerHTML = "El numero es negativo";
    }*/

    if(!isNaN(valorNumerico) || valor== "" ){
        if(valorNumerico >= 0){
            parrafo.innerHTML = "El numero es positivo";
        } else{
            parrafo.innerHTML = "El numero es negativo";
        }   
    }
    else{
        parrafo.innerHTML = "Por favor ingrese un numero";
    }
}

let cantidadNumeros = 0;
let sumaTotal = 0;
let misNumeros = "";
function ejer18(){
    let valor = document.querySelector("#txtEjer18Numero").value;
    let valorNumerico = Number(valor);
    let parrafo = document.querySelector("#pEjer18Resultado");
    if(!isNaN(valorNumerico) || valor== "" ){
        if(valorNumerico >= 0){
            sumaTotal = sumaTotal + valorNumerico; 
        } else{
            valorNumerico = valorNumerico * -1;
            sumaTotal = sumaTotal + valorNumerico;
        }   
        misNumeros = misNumeros + ", " + valorNumerico
        cantidadNumeros++;
    }
    else{
        parrafo.innerHTML = "Lo ultimo ingresado no fue un numero, no conto";
    }
    if(cantidadNumeros == 6){
        parrafo.innerHTML = "La suma absoluta total de sumar los numeros" + misNumeros + "es: " + sumaTotal;
        cantidadNumeros = 0;
        sumaTotal = 0;
    }

}