/*Recomiendo antes de empezar a escribir codigo tomarnos unos minutos para pensar que debe retornar cada funcion y que parametros recibe y en base a eso resolver  */


/*PARTE A
 Crear la interfaz HTML (solamente el contenido de dentro del body) y la funcionalidad javascript
para crear la interfaz para registrar el préstamo de libros a los usuarios. Se solicitará el nombre
del usuario, el libro que desea llevar en préstamo y la cantidad deseada. Se valorará la creación
dinámica de un combo desplegable con los títulos de los libros disponibles (prestar atención a
qué dato se debe almacenar del libro). En esta parte, no es necesario almacenar información,
solo crear la interfaz.*/

//No lo dice explicitamente la letra, pero por lo que hemos trabajado en el curso sabemos que necesitamos un botón para que el usuario nos "avise" que ingreso los datos


let sistema = new Sistema()
//PARTE A -js
armarComboLibros()
function armarComboLibros() {
    let contenidoSelect = `<option value="-1">Seleccione un libro</option>`;
    for (let i = 0; i < sistema.libros.length; i++) {
        //es importante definir que es value y que es visible al usuario
        //Lo que voy a terminar guardando en el prestamo es el id del libro, por eso este es el value, lo que muestro al usuario es lo que va entre las etiquetas, en este caso el titulo
        contenidoSelect += `<option value="${sistema.libros[i].id}">${sistema.libros[i].titulo}</option>`;
    }
    document.querySelector("#slcLibros").innerHTML = contenidoSelect;
}


/* PARTE B
 Crear la/s clase/s y array/s necesarios para manejar la información a utilizar en la aplicación. Lo
que se plantee dentro del constructor de la clase Sistema se debe aclarar con un comentario
Javascript.*/

/* 
//Propiedades en clase sistema
class Sistema {
    constructor() {       
        //resto del código       
        this.prestamos = [];
        this.ultimoPrestamo = 1;
} 
*/

/*
class Prestamo{
    constructor(idPrestamo,nombreUsuario,idLibro,cantidad){
        this.idPrestamo = idPrestamo;
        this.nombreUsuario = nombreUsuario;
        this.idLibro = idLibro;
        this.cantidad = cantidad;
    }

}*/



/* PARTE D
Crear la funcionalidad para, utilizando el HTML creado, hacer un registro de un préstamo. Cada
préstamo se almacenará en un array de prestamos, con objetos Prestamo que contendrán el
nombre del usuario, el id (u objeto) del libro prestado, la cantidad y un id que será un valor
numérico único autoincremental. Se deberá validar que la cantidad a prestar no exceda la
disponible y que no se haya realizado un préstamo de ese libro previamente a ese mismo usuario.
En caso de error, mostrar un mensaje en un párrafo. */

/*
Interpretación letra: 
En esta parte tenemos que resolver varias cosas
1) Obtener desde el html los valores ingresados por el usuario
2) Verificar que haya stock disponible para el libro
3) Verificar que no exista un prestamo para el mismo usuario y libro ingresados por el usuario
4) Agregar prestamo
*/

document.querySelector("#btnGuardar").addEventListener("click", registrarPrestamo)

function registrarPrestamo() {
    let nombreIngresado = document.querySelector("#txtNombre").value;
    let libroSeleccionado = Number(document.querySelector("#slcLibros").value);
    let cantidadEjemplaresIngresados = Number(document.querySelector("#txtCantidad").value);
    let mensajeUsuario =""
    if(nombreIngresado !="" && cantidadEjemplaresIngresados>0 && libroSeleccionado>0){
       mensajeUsuario = sistema.agregarPrestamo(nombreIngresado, libroSeleccionado, cantidadEjemplaresIngresados)    
    }else{
        mensajeUsuario = "Verifique datos ingresados"
    }   
    document.querySelector("#pNotificacionUsuario").innerHTML = mensajeUsuario
    /*
    //Esta linea es para probar la parte G, no es parte de la funcionalidad 
    armarTablaCantUsuariosPorLibro(); 
    */
}


/*PARTE G
Crear una función y el código HTML necesario para que se muestre en una tabla todos los títulos
de libros y la cantidad de usuarios que han realizado préstamos de cada libro. 


Interpretacion letra:
Cuando hacemos tablas es importante decidir una tabla "de que" estamos haciendo para asi poder decidir que array
tomamos como base para recorrer, en este caso, aunque mostremos la cantidad de usuarios a los que se les presto el libro, 
es una tabla de libros, para cada libro nosotros queremos obtener la cantidad de usuarios.

Una vez resuelto esto, podemos observar que la cantidad de usuarios nosotros ya sabemos como obtenerla, es la funcion de la parte e,
por lo tanto, podemos reutilizar esta funcion e invocarla para cada libro.
 */

function armarTablaCantUsuariosPorLibro() {
    document.querySelector("#tblCantUsuariosLibro").innerHTML = ""
    for (let i = 0; i < sistema.libros.length; i++) {
        let unLibro = sistema.libros[i];
        document.querySelector("#tblCantUsuariosLibro").innerHTML += ` <tr>
        <td>
            ${unLibro.titulo}
        </td>
        <td>
            ${sistema.obtenerCantidadUsuariosLibro(unLibro.id)}
        </td>
    </tr>`
    }
}