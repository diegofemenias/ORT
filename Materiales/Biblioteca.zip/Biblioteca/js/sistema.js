
class Sistema {
    constructor() {
        this.libros = [
            new Libro(1, "Cien años de soledad", "Gabriel García Márquez", 3),
            new Libro(2, "Don Quijote de la Mancha", "Miguel de Cervantes", 5)
        ];
        //En sistema
        //Recordar que las variables declaradas en el constructor de la clase sistema no llevan la palabra reservada let.
        this.prestamos = [];
        this.ultimoId = 1;
    }

    /*PARTE C 
     Crear un método de la clase Sistema obtenerCantidadPrestados que reciba como parámetro un
   id de libro y devuelva la cantidad de libros que han sido prestados.  
   
   Interpretación letra:
   Como es un metodo no lleva palabra reservada function 
   Cada prestamo puede incluir mas de un libro, por lo tanto corresponde ir incrementando nuestra variable 
   cantidadLibros sumando la cantidad de libros de cada prestamo

   */

    obtenerCantidadPrestados(idLibro) {
        let cantidadLibros = 0;
        for (let i = 0; i < sistema.prestamos.length; i++) {
            if (idLibro === sistema.prestamos[i].idLibro) {
                cantidadLibros += sistema.prestamos[i].cantidad;
            }
        }
        return cantidadLibros;
   }


    generarProximoId() {
        let idActual = this.ultimoId;
        this.ultimoId++;
        return idActual;
    }

    agregarPrestamo(nombreIngresado, libroSeleccionado, cantidadEjemplaresIngresados) {
        let mensajeUsuario="";
        let stockDisponible = sistema.verificarStock(libroSeleccionado, cantidadEjemplaresIngresados);
        let existe = false;
        if (stockDisponible) {
        let i=0;
        while(!existe && i<sistema.prestamos.length){
            let unPrestamo = sistema.prestamos[i];
            if (unPrestamo.nombreUsuario === nombreIngresado && unPrestamo.idLibro === libroSeleccionado) {
                existe = true;
            }
            i++;
        } 
        if (!existe) {
            let nuevoPrestamo = new Prestamo(sistema.generarProximoId(), nombreIngresado, libroSeleccionado, cantidadEjemplaresIngresados)
            this.prestamos.push(nuevoPrestamo)
            mensajeUsuario = "Prestamo registrado"
        } else {
            //Si existe es verdadero, no agrego, pero le muestro un mensaje al usuario para que entienda que paso 
            mensajeUsuario = "Ya existe un prestamo de ese libro para ese usuario"
        }

        } else {
            mensajeUsuario = "No hay stock disponible del libro seleccionado"
        }
        return mensajeUsuario;        
    }

    verificarStock(libroSeleccionado, cantidadPedidos) {
        let stockDisponible = false;
        let cantidadNecesaria = cantidadPedidos + this.obtenerCantidadPrestados(libroSeleccionado);
        for (let i = 0; i < this.libros.length; i++) {
            let unLibro = this.libros[i];
            if (unLibro.id === libroSeleccionado && unLibro.cantidad >= cantidadNecesaria) {
                stockDisponible = true
            }
        }
        return stockDisponible;
    }
  

    /*PARTE E
     Crear un método de la clase Sistema obtenerCantidadUsuariosLibro que reciba como parámetro
    un idLibro y devuelva la cantidad de usuarios que han realizado préstamos de ese libro. */

    /*
    Interpretacion letra: Por lo que trabajamos en partes anteriores, sabemos que cada usuario puede pedir un mismo libro
    una sola vez, por lo tanto podemos asegurar que cada reserva para el libro recibido por parametro sera para un usuario distinto 
    y que cantReservasLibro === cantUsuariosReservaronLibro.
     */
    obtenerCantidadUsuariosLibro(idLibro) {
        let cantidadUsuariosLibro=0;
        for (let i = 0; i < this.prestamos.length; i++) {
            if (idLibro === this.prestamos[i].idLibro)
                cantidadUsuariosLibro++
        }
        return cantidadUsuariosLibro;
    }

    /*
    PARTE F
    
    Crear un método de la clase Sistema obtenerPrestamosUsuarioConPalabraEnTitulo que reciba
    como parámetro el nombre de un usuario y un texto y devuelva un array con los préstamos que
    ha realizado dicho usuario que sean de libros que contengan el texto recibido como segundo
    parámetro en el título. Recordar que en los préstamos se almacena el id del libro o el objeto libro.
    La búsqueda del usuario deberá ser case insensitive. */

    /*
    Interpretacion letra: esta funcion va a recibir dos parametros, el nombre de un usuario y un texto. 
    Debe retornar un array con los prestamos (objetos prestamo) que ha realizado el usuario recibido cuyo titulo contiene el texto del segundo parametro
    
    indexOf() -> Metodo de Strings que que retorna el "indice de", la posicion del elemento recibido como parametro en el string.En caso de no encontrarlo retorna -1
    Ejemplo:
    let palabra = "hola"
    console.log(palabra.indexOf("ol") ) -> 1
    console.log(palabra.indexOf("parcial") ) -> -1
    
    */
    obtenerPrestamosConPalabraEnTitulo(nombreUsuario, texto) {
        let arrayPrestamos = [];
        let nombreLibro;
        for (let i = 0; i < this.prestamos.length; i++) {
            let unPrestamo = this.prestamos[i]
            if (unPrestamo.nombreUsuario.toLowerCase() === nombreUsuario.toLowerCase()) {
                nombreLibro = this.obtenerNombreLibro(unPrestamo.idLibro) 
                if(nombreLibro.indexOf(texto) > -1){
                    arrayPrestamos.push(unPrestamo)
                }
            }
        }
        return arrayPrestamos;
    }

    //Metodo que obtiene el nombre del libro dado el id
    obtenerNombreLibro(idLibro){
        let nombreLibro =""
        let i=0;
        while(nombreLibro ==="" && i<this.libros.length){
            let unLibro = this.libros[i];
            if(idLibro === unLibro.id){
                nombreLibro = unLibro.titulo;
                
            }  
        }    
        return nombreLibro
    }

}
