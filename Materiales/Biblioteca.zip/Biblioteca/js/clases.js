class Libro {
    constructor(id, titulo, autor, cantidad) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.cantidad = cantidad;
    }
}


class Prestamo {
    constructor(idPrestamo, nombreUsuario, idLibro, cantidad) {
        this.idPrestamo = idPrestamo;
        this.nombreUsuario = nombreUsuario;
        this.idLibro = idLibro;
        this.cantidad = cantidad;
    }
}
