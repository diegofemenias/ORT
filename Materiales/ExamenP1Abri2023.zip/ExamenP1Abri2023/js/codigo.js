let sistema = new Sistema();
cargarSelectAlumnos();
//tablasLlegadas(2)



function cargarSelectAlumnos(){
    let comboAlumnos = document.querySelector("#slcAlumnos");
    let misAlumnos = "";
    for(let alumno of sistema.alumnos){
        misAlumnos += `<option value="${alumno.id}">${alumno.nombre} (${alumno.id})</option>`
    }
    comboAlumnos.innerHTML = misAlumnos;

}


document.querySelector("#btnRegistrar").addEventListener("click",registrarAsistencia);
function registrarAsistencia(){
    let idAlumno = Number(document.querySelector("#slcAlumnos").value);
    let fecha = document.querySelector("#txtFecha").value;
    let presente = document.querySelector("#slcAsistencia").value;
    
    let alumnoValido = sistema.buscarAlumnoActivoPorId(idAlumno);
    if(alumnoValido !== null ){
        let asistenciaYaIngresada = sistema.existeAsistenciaEnDia(idAlumno,fecha);
        if(!asistenciaYaIngresada){
            sistema.registrarAsistencia(idAlumno,fecha,presente);
            alert("Asistencia registrada");
        }else{
            alert("la asistencia ya fue ingresada");
        }
    }else{
        alert("El alumno no está activo");
    }

}


function tablasLlegadas(idAlumno){

    let alumno = sistema.buscarAlumnoActivoPorId(idAlumno)
    if(alumno != null){
        let tardes = sistema.obtenerAsistenciasTipo(idAlumno,1);
        let enHora = sistema.obtenerAsistenciasTipo(idAlumno,0);

        let tablaTardes="";
        let tablaEnHora = "";
        for(let asistencia of tardes){
            tablaTardes += `<tr> 
                <td>idAsistencia ${asistencia.id}</td>
                <td>${asistencia.fecha}</td>
            </tr>` 
        }
        
        for(let asistencia of enHora){
            tablaEnHora += `<tr> 
                <td>idAsistencia ${asistencia.id}</td>
                <td>${asistencia.fecha}</td>
            </tr>` 
        }

        document.querySelector("#tblTarde").innerHTML = tablaTardes;
        document.querySelector("#tblEnHora").innerHTML = tablaEnHora;


    }

}
