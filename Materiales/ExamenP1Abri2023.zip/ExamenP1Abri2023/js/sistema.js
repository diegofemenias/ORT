class Sistema {
    constructor() {
        this.asistencias = [
            new Asistencia(1, 2, "2023-03-01", 1, 0),
            new Asistencia(2, 1, "2023-03-01", 1, 0),
            new Asistencia(3, 3, "2023-03-01", 0, 0),
            new Asistencia(4, 2, "2023-03-02", 1, 1),   


        ]

        this.alumnos = [
            new Alumno(1, "Marcelo Perez", 21, 1),
            new Alumno(2, "Sabrina Garcia", 24, 1),
            new Alumno(3, "Javier Moreira", 23, 0)

        ];
        this.ultimoIdAsistencia = 4;
    }


    buscarAlumnoActivoPorId(idAlumno) {
        let encontrado = false;
        let i = 0;
        let retAlumno = null;
        while (!encontrado && i < this.alumnos.length) {
            if (idAlumno == this.alumnos[i].id) {
                encontrado = true;
                if (this.alumnos[i].activo === 1) {
                    retAlumno = this.alumnos[i];
                }
            }
            i++;
        }
        return retAlumno;
    }
    //Sabemos que llegada tarde va a tomar lo valores 0 o 1
    obtenerAsistenciasTipo(idAlumno, llegadaTarde) {
        let retAsistencias = [];
        for (let asistencia of this.asistencias) {
            if (asistencia.idAlumno == idAlumno && asistencia.llegadaTarde == llegadaTarde && asistencia.presente == 1) {
                retAsistencias.push(asistencia);
            }
        }
        return retAsistencias;

    }


    existeAsistenciaEnDia(idAlumno,fecha){
        let encontado = false;
        let i = 0;
        while(!encontado && i<this.asistencias.length){
            if(this.asistencias[i].idAlumno == idAlumno && this.asistencias[i].fecha == fecha ){
                encontado = true;
            }
            i++;
        }
        return encontado; 
    }

    registrarAsistencia(idAlumno,fecha,presente){
        let nuevaAsistencia = new Asistencia(this.ultimoIdAsistencia + 1,idAlumno,fecha,presente,0 );
        this.asistencias.push(nuevaAsistencia);
        this.ultimoIdAsistencia++;
    }

    modificarAsistencia(idAlumno,fecha){
        let encontrado = false;
        let i = 0;
        while(!encontrado && i<this.asistencias.length){
            if(this.asistencias[i].idAlumno == idAlumno && 
                this.asistencias[i].fecha == fecha && 
                this.asistencias[i].presente == 1)
            {
                this.asistencias[i].llegadaTarde = 1;
                encontrado = true;                
            }
            i++;
        }
    }
}
