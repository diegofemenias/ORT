class Alumno{
    constructor(id,nombre,edad,activo){
        this.id=id;
        this.nombre=nombre;
        this.edad=edad;
        this.activo=activo;
    }
}