class Asistencia {
    constructor(id, idAlumno, fecha, presente, llegadaTarde) {
        this.id = id;
        this.idAlumno = idAlumno;
        this.fecha = fecha;
        this.presente = presente;
        this.llegadaTarde = llegadaTarde;
    }
}