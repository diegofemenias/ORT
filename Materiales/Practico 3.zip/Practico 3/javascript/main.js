document.querySelector("#btnContar1").addEventListener("click",contarHasta1000);
document.querySelector("#btnCalcular6").addEventListener("click",ejercicio6);
document.querySelector("#btnFactorial12").addEventListener("click",factorial);

function contarHasta1000(){
    let parrafo = document.querySelector("#pResultado1");
    let resultado = "";
    /*for (let i = 1; i <= 1000; i++) {
        resultado += i + "<br>";
    }*/
    let i = 1;
    while (i<=1000){
        resultado += i + "<br>";
        i++;
    }
    parrafo.innerHTML = resultado;
}

function ejercicio6(){
    let parrafo = document.querySelector("#pResultado6");
    let resultado = "";
    for(let i= -33; i<= 230; i = i+4){
        if(i%4==0){
            resultado = resultado + i + "<br>";
        }
    }
    parrafo.innerHTML = resultado;
}

function factorial(){
    let numero = Number(document.querySelector
    ("#txtNumero12").value);
    let parrafo = document.querySelector("#pResultado12");
    let resultado = 1;
    /*for(let i = 1; i<=numero;i++){
        resultado = resultado * i;
    }*/
    let i = 1;
    while(i<=numero){
        resultado = resultado * i;
        i++;
    }
    parrafo.innerHTML = resultado;
}
