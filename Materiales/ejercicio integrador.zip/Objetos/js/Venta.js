class Venta{
    constructor(unVendedor, unVehiculo){
        this.vendedor = unVendedor;
        this.vehiculo = unVehiculo;
    }
}