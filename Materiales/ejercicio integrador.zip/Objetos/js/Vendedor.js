class Vendedor {
    constructor(usuario, pass, unNombre, unApellido) {
        this.usuario = usuario;
        this.password = pass;
        this.nombre = unNombre;
        this.apellido = unApellido;
        this.ventas = 0;
    }



}