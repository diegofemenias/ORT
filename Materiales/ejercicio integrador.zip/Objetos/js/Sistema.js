class Sistema{
    constructor(){
        this.vehiculos = [];
        this.vendedores = [];
        this.ventas = [];
        this.vendedorLogueado = null;
        this.ultId=0;
        this.precargarVehiculos();      
        this.precargarVendedores()
    }

    precargarVehiculos(){
        let auto = new Vehiculo(1,"Chevrolet", "Onix", 2018, "Blanco", true);
        let camioneta = new Vehiculo(2,"Fiat", "Strada", 2023, "Rojo", false);  
        let camion = new Vehiculo(3,"JAC", "x200", 2020, "Blanco", true);
        this.vehiculos = [auto, camioneta, camion];
        this.ultId = this.vehiculos.length;
    }  

    precargarVendedores(){
        let vendedor1 = new Vendedor("pepe","123","Pedro","Gonzalez");
        let vendedor2 = new Vendedor("ana","123","Ana","Perez");
        //this.vendedores = [vendedor1,vendedor2];
        this.vendedores.push(vendedor1);
        this.vendedores.push(vendedor2);
    }  

   agregarVehiculo(marca,modelo,color,anio,alDia){
        let nuevoVehiculo = new Vehiculo(this.ultId + 1,marca,modelo,color,anio,alDia)
        this.vehiculos.push(nuevoVehiculo)
        this.ultId += 1; 
   }

   obtenerVehiculos(){
    let disponibles=[];
    for(let v of this.vehiculos){
        if(v.disponible){
            disponibles.push(v);
        }
    }

    return disponibles;
   }

   obtenerVendedores(){
      return this.vendedores;
   }


   login(usuario,pass){

    let encontrado = false;
    let i=0;
    while(!encontrado && i < this.vendedores.length){
        let vendedor = this.vendedores[i]
        if(vendedor.usuario === usuario && vendedor.password === pass){
            encontrado = true;
            this.vendedorLogueado = vendedor;
        }
        i++;
    }

    return encontrado;

   }

   cerrarSesion(){
    this.vendedorLogueado = null;
   }

   vender(id){
    let encontrado = false;
    let i = 0;
    while(!encontrado && i < this.vehiculos.length ){
        let vehiculo = this.vehiculos[i];
        if(vehiculo.id == id){
            encontrado = true;
            vehiculo.disponible = false;
            this.vendedorLogueado.ventas += 1;
            let venta = new Venta(this.vendedorLogueado,vehiculo);
            this.ventas.push(venta)
        }
        i++;
    }
   }


   obtenerUsuarioLogueado(){
    return this.vendedorLogueado;
   }

}