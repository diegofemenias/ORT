let sistema = new Sistema();

//console.log(this)
//Eventos de botones
document.querySelector("#btnAgregar").addEventListener("click",agregarVehiculo);
document.querySelector("#btnMostrarAltaVehiculo").addEventListener("click",mostrarSeccion);
document.querySelector("#btnMostrarListaVehiculos").addEventListener("click",mostrarSeccion);
document.querySelector("#btnMostrarListaVendedores").addEventListener("click",mostrarSeccion);
document.querySelector("#btnLogin").addEventListener("click",login);
document.querySelector("#btnCerrarSesion").addEventListener("click",cerrarSesion);


document.querySelector("#txtUsuario").value = "pepe";
document.querySelector("#txtPass").value = "123";


listarVehiculos();
listarVendedores();   

ocultarTodo();
ocultarMostrarCabezal("ocultar");
//document.querySelector("#btnMostrarAltaVehiculo").click()
mostrarSeccionSegunId("slogin");


function ocultarMostrarCabezal(accion){
    if(accion === "mostrar"){
        document.querySelector("#cabezal").style.display = "block"
    }else{
        document.querySelector("#cabezal").style.display = "none"

    }
}

function ocultarTodo(){
    let secciones = document.querySelectorAll(".seccion");
    for(let s of secciones){
        s.style.display="none";
    }
}
function mostrarSeccion(){
    let idSection = this.getAttribute("data-refSecction")
    mostrarSeccionSegunId(idSection)
}
function mostrarSeccionSegunId(idSeccion){
    ocultarTodo();
    document.querySelector(`#${idSeccion}`).style.display = "block";
}



function agregarVehiculo(){
    let marca = document.querySelector("#txtMarca").value;
    let modelo = document.querySelector("#txtModelo").value;
    let color = document.querySelector("#txtColor").value;
    let anio = Number(document.querySelector("#txtAnio").value);
    let slcAlDia = document.querySelector("#slcAlDia").value;
    let alDia = false;
    if(slcAlDia === "s"){
        alDia=true;
    }
    sistema.agregarVehiculo(marca,modelo,color,anio,alDia);
    listarVehiculos();

}



function listarVehiculos(){
    vehiculos = sistema.obtenerVehiculos()
    let tablaVehiculos="";
    for (let i = 0; i < vehiculos.length; i++) {
        tablaVehiculos += `
          <tr>
          <td>${vehiculos[i].marca}</td>
          <td>${vehiculos[i].modelo}</td>
          <td>${vehiculos[i].color}</td>
          <td>${vehiculos[i].anio}</td>
          <td>${vehiculos[i].obtenerAldia()}</td>
          <td><input type="button" value="Vender" id="btnVender${vehiculos[i].id}" data-ref="${vehiculos[i].id}" class="btnVender"></td>

          </tr>
          `;
      }

    document.querySelector("#tblVehiculos").innerHTML = tablaVehiculos;    
    let botones = document.querySelectorAll(".btnVender")
    for(let boton of botones){
        boton.addEventListener("click",vender);
    }
    
}

function vender(){
    let vehiculoId = this.getAttribute("data-ref")
    console.log(vehiculoId)
    sistema.vender(vehiculoId)
    listarVehiculos();
    listarVendedores();
}


function listarVendedores(){
    let vendedores = sistema.obtenerVendedores();    
    let tablaVendedores = "";
    for(let i = 0; i<vendedores.length;i++){
        tablaVendedores += `
        <tr>
         <td>${vendedores[i].nombre}</td>
         <td>${vendedores[i].apellido}</td>
         <td>${vendedores[i].ventas}</td>
         </tr>
        `
    }

    document.querySelector("#tblVendedores").innerHTML = tablaVendedores;             
}


function login(){
    let parrafo = document.querySelector("#pLogin");
    let usuario = document.querySelector("#txtUsuario").value;
    let pass = document.querySelector("#txtPass").value;
    document.querySelector("#txtPass").value = "";

    if(usuario === "" || pass === ""){
        parrafo.innerHTML = "Debe comletar ambos campos";
    }else{

        let loginOK=sistema.login(usuario,pass)

        if(loginOK){
            ocultarMostrarCabezal("mostrar");
            ocultarTodo();
            mostrarSeccionSegunId("sListaVehiculos");
            document.querySelector("#pUsuario").innerHTML = sistema.obtenerUsuarioLogueado().nombre
            
        }else{
            parrafo.innerHTML = "Usuario y/o pass incorrectos";
            
        }

    }


}

function cerrarSesion(){
    sistema.cerrarSesion();
    ocultarMostrarCabezal("ocultar");
    ocultarTodo();
    mostrarSeccionSegunId("slogin");

}