class Vehiculo {
    constructor(id,unaMarca, unModelo, unaAnio, color, alDia) {
      this.id = id;
      this.marca = unaMarca;
      this.modelo = unModelo;
      this.anio = unaAnio;
      this.color = color;
      this.alDia = alDia;
      this.disponible = true;
    }
  
    cambiarColor(color) {
      if (this.anio > 2020) {
        this.color = color;
        return true;
      } else {
        return false;
      }
    }
  
    pagarPatente() {
      if (!this.alDia) {
        return true;
      } else {
        return false;
      }
    }
  
    obtenerAldia() {
      if (this.alDia) {
        return "Si";
      } else {
        return "No";
      }
    }
  }